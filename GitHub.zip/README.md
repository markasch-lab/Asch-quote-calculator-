# Asch Quote Calculator

A Vite + React app for quote calculation, proposal generation, invoice generation, rate sheets, and PDF export.

## Run locally
npm install
npm run dev

## Build
npm run build
